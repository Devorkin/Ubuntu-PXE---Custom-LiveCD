#!/bin/bash
cd $(dirname $0)
killall conky 2> /dev/null
mkdir ~/.fonts > /dev/null 2>&1 
cp fonts/*.*tf ~/.fonts > /dev/null 2>&1 
mkdir ~/.local/share/fonts/ > /dev/null 2>&1 
cp fonts/*.*tf ~/.local/share/fonts/ > /dev/null 2>&1 
fc-cache ~/.fonts
python info01.py    || python3 info01.py 
python clock01.py   || python3 clock01.py
python net01.py     || python3 net01.py
conky -q -c clockfile
conky -q -c netfile
